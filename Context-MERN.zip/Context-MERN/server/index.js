import express from 'express'
import tasksRoutes from './routes/task.routes.js'
import {connectDB} from './db.js'
import { PORT } from './config.js'

const app = express()
connectDB()

app.use(tasksRoutes)

app.listen(PORT)
console.log('Servidor corriendo puerto',PORT)

