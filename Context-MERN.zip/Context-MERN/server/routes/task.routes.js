import {Router} from "express"
import {getTasks, createTask, updateTask, deleteTask, getTask} from '../Controllers/task.controllers.js'
const router = Router()

router.get('/tasks',getTasks)
router.post('/tasks',createTask)
router.put('/tasks',updateTask)
router.delete('/tasks',deleteTask)
router.get('/tasks/:id',getTask)

export default router