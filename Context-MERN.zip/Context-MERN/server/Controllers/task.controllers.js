export const getTasks = (req,res)=>res.send([])

export const createTask = (req,res)=>res.send('Nuevo creado')

export const updateTask = (req,res)=>res.send('Actualizado')
export const deleteTask = (req,res)=>res.send('Eliminando')
export const getTask = (req,res)=>res.send('Obtiene')
